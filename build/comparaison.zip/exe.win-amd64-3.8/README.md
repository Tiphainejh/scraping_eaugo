# Infos générales

Modifier le fichier json : 
	Sur le site https://jsoneditoronline.org/, mettre copier le fichier dans la section "code" puis cliquer sur la section "tree" pour voir l'arborescence.

Lancer le programme :
	Cliquer sur le fichier "comparer.exe"
	Le résultat est dans le fichier "comparaison.xlsx"

Il faut veiller à ne pas modifier les fichiers présents dans le dossier!!


# Infos développeurs

Créer le fichier .exe :
```python setup.py build```